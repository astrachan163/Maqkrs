import { weekContent as weeks } from './weeks';
export const weekContent = weeks;
export default weekContent;